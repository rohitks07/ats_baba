<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/moltran/blue/pages-500.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Jun 2019 12:16:17 GMT -->
<head>
        <meta charset="utf-8" />
        <title>Ats</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <link rel="shortcut icon" href="{{url('assets/images/favicon_1.ico')}}">
        
        <!-- Custom Files -->
        <link href="{{url('assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{url('assets/css/icons.css')}}" rel="stylesheet" type="text/css" />
        <link href="{{url('assets/css/style.css')}}" rel="stylesheet" type="text/css" />
        <script src="{{url('assets/js/modernizr.min.js')}}"></script>
        
    </head>
    <body>

        <div class="wrapper-page">
            <div class="ex-page-content text-center">
                <h1>404</h1>
                <h2 class="font-light">Campany  Page Not Found.</h2><br>
                <!-- <p>Why not try refreshing your page? or you can contact <a href="#">support</a></p> -->
                <a class="btn btn-purple waves-effect waves-light" href="{{url('/')}}"><i class="fa fa-angle-left"></i> Back to Dashboard</a>
                <a class="btn btn-purple waves-effect waves-light" href="{{url('jobpostsignup')}}"><i class="fa fa-angle-left"></i> Register Your Company In Ats</a>
                
            </div>


        </div>

        
    	<script>
            var resizefunc = [];
        </script>

        <!-- Main  -->
        <script src="{{url('assets/js/jquery.min.js')}}"></script>
        <script src="{{url('assets/js/bootstrap.bundle.min.js')}}"></script>
        <script src="{{url('assets/js/detect.js')}}"></script>
        <script src="{{url('assets/js/fastclick.js')}}"></script>
        <script src="{{url('assets/js/jquery.slimscroll.js')}}"></script>
        <script src="{{url('assets/js/jquery.blockUI.js')}}"></script>
        <script src="{{url('assets/js/waves.js')}}"></script>
        <script src="{{url('assets/js/wow.min.js')}}"></script>
        <script src="{{url('assets/js/jquery.nicescroll.js')}}"></script>
        <script src="{{url('assets/js/jquery.scrollTo.min.js')}}"></script>
        <script src="{{url('assets/js/jquery.app.js')}}"></script>
	
	</body>

<!-- Mirrored from coderthemes.com/moltran/blue/pages-500.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 27 Jun 2019 12:16:17 GMT -->
</html>