<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_companies extends Model
{
     public $timestamps = false;
     public  $table = "tbl_companies";
}
