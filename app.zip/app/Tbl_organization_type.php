<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_organization_type extends Model
{
	 public $timestamps = false;
     public  $table = "tbl_organization_type";
}
