<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_forward_emp_details extends Model
{
    public $timestamps = false;
    public  $table = "tbl_forward_emp_details";
}
