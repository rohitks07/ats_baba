<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_job_post_assign extends Model
{
	public $timestamps = false;
     public  $table = "tbl_job_post_assign";
}
