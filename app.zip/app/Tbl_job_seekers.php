<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_job_seekers extends Model
{
    public $table= 'tbl_job_seekers';
    public $timestamps = false;
    
   
}
