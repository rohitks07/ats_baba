<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_marketing_emailer extends Model
{
    public $timestamps=false;
    public $table ="tbl_marketing_emailer";
}
