<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_schedule_interview extends Model
{
    public $table= 'tbl_schedule_interview';
    public $timestamps = false;
   
}
