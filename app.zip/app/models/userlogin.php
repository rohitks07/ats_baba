<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class userlogin extends Model
{
	public $timestamps = false;
     public  $table = "userlogin";
}
