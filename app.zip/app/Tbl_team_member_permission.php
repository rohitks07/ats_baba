<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_team_member_permission extends Model
{
    public $timestamps = false;
     public  $table = "tbl_team_member_permission";
}
