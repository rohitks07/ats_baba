<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class states extends Model
{
    public $timestamps = false;
     public  $table = "states";

}
