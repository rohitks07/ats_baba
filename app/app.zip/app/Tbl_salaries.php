<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_salaries extends Model
{
     public $timestamps = false;
     public  $table = "tbl_salaries";
}
