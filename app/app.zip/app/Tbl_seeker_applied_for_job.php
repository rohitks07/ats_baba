<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_seeker_applied_for_job extends Model
{
    public $timestamps = false;
    
    protected  $table = "tbl_seeker_applied_for_job"; 
}
