<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobseekerSignupModel extends Model
{
    public $timestamps = false;
    public  $table = "tbl_job_seekers";
}
