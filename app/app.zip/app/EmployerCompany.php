<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmployerCompany extends Model
{
   public $timestamps = false;
    public  $table = "tbl_invite_jobseeker";
}
