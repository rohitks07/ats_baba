<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invite_jobseeker extends Model
{
    public $timestamps = false;
    public  $table = "tbl_invite_jobseeker";
}
