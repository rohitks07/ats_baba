<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_candidate_notes extends Model
{
    public $timestamps=false;
    protected $table='tbl_candidate_notes';
}
