<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Pay_UMO extends Model
{
      public $timestamps = false;
     public  $table = "tbl_pay_rate_umo";

}
