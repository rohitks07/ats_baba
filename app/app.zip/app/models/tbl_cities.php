<?php

namespace App;


use Illuminate\Database\Eloquent\Model;


class tbl_cities extends Model
{
    public $timestamps = false;
     public  $table = "tbl_cities";
}
