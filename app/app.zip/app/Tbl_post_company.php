<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_post_company extends Model
{
      public $timestamps = false;
    public  $table = "tbl_post_company";

}
