<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_ad_codes extends Model
{
    public $timestamps = false;
    public  $table = "tbl_ad_codes";

}
