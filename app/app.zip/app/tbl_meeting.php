<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_meeting extends Model
{
    public $timestamps = false;
}
