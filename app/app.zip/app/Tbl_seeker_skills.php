<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_seeker_skills extends Model
{    
    public $timestamps = false;
    protected  $table = "tbl_seeker_skills"; 
}
