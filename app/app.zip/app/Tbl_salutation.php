<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_salutation extends Model
{
    public $timestamps = false;
    
    protected  $table = "tbl_salutation"; 
}
