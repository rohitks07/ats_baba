<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_countries extends Model
{
     public $timestamps = false;
     public  $table = "tbl_countries";
}
