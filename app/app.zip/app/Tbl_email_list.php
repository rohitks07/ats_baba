<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_email_list extends Model
{
    public $timestamp=false;
    protected $table="tbl_email_list";
 
}
