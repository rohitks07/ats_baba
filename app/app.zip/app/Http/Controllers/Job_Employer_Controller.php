<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use Session; 
use App\Tbl_cities;
use App\Tbl_countries;
use App\Tbl_email_list;
use App\Tbl_email_list_contacts;
use App\tbl_job_industries;
use App\Tbl_job_post_assign;
use App\Tbl_job_seekers;
use App\tbl_meeting;
use App\Tbl_post_contacts;
use App\tbl_post_job;
use App\tbl_post_jobs;
use App\tbl_schedule_interview;
use App\Tbl_seeker_academic;
use App\Tbl_seeker_applied_for_job;
use App\Tbl_seeker_applied_for_job_doc;
use App\Tbl_seeker_experience;
use App\Tbl_seeker_skills;
use App\tbl_team_member;
use App\Tbl_team_member_type;
use App\Tbl_visa_type;
use App\Tbl_state; 
use App\Tbl_qualifications;
use App\Tbl_notification;
use App\Tbl_team_member_permission;
use App\Tbl_module;
use App\user;
use Validator;





class Job_Employer_Controller extends Controller
{
    public function dashboard()
    {
            $toReturn['job_post']= tbl_post_job::paginate(10);
            $toReturn['interview']= tbl_schedule_interview::get()->toArray();
            $toReturn['meeting']= tbl_meeting::get()->toArray();
            $toReturn['assign']=Tbl_job_post_assign::get()->toArray();
            $toReturn['application']= Tbl_seeker_applied_for_job::leftjoin('tbl_post_jobs as post_jobs','tbl_seeker_applied_for_job.job_ID','=','post_jobs.ID')
            ->leftjoin('tbl_job_seekers as seeker','tbl_seeker_applied_for_job.seeker_ID','=','seeker.ID')
            ->select('post_jobs.job_code as job_code','post_jobs.job_title as job_title','post_jobs.client_name as job_client_name','post_jobs.country as location','post_jobs.job_visa_status as  job_visa','post_jobs.pay_min as pay_min','post_jobs.pay_max as pay_max','seeker.first_name as can_first_name','seeker.last_name as can_last_name','seeker.country as can_location','seeker.visa_status as can_visa','tbl_seeker_applied_for_job.dated as applied_date')
            ->paginate(10);
        return view('employerdashboard')->with('toReturn',$toReturn);
    }
    
    
    public function status(Request $request){
        $id=$request->id;
        $status=$request->sts;
        if($status=='deleted'){
            $stsdelete=tbl_post_job::where('ID',$id)->delete();
        }
        
        tbl_post_job::where('ID', $id)->update(array(
            'sts'=>$status
        ));
        
        
    return redirect('employer/dashboard');
    
    }

    public function view_post_form()
    {
            $toReturn=array();
            $toReturn['team_member_type']=tbl_team_member_type::get()->toArray();
            $toReturn['post_job']        =tbl_post_jobs::get()->toArray();
            $toReturn['team_member']     =tbl_team_member::get()->toArray();
            $toReturn['job_industries']  =tbl_job_industries::get()->toArray();
        return view('post_new_job')->with('toReturn',$toReturn);
    }

    public function Add_to_post_job(Request $request)
    {      
            // $this->validate($request,[
            //  'group_of_company'=> 'required',
            //  'company_name'    => 'required',
            //  'privacy_level'   => 'required',
            //  'owner_name'      => 'required',
            //  'status'          => 'required',
            //  'industry'        => 'required',
            //  'job_code'        => 'required',
            //  'job_title'       => 'required',
            //  'no_of_vacancies' => 'required',
            //  'closeing_date'   => 'required',
            //  'job_visa_status' => 'required',
            //  'qualification'   => 'required',
            //  'country'         => 'required',
            //  'state'           => 'required',
            //  'city'            => 'required',
            //  'type_of_job'     => 'required',
            //  'job_duration'    => 'required',
            //  'day_week'        => 'required',
            //  'pay_min'         => 'required',
            //  'pay_max'         => 'required',
            //  'pay_uom'         => 'required',
            //  'experience'      => 'required',
            //  'requirement'     => 'required',
            //  'requirements'    => 'required',
            //  'job_desc'        => 'required',
            //  'skill'           => 'required'
            // ] );
            
            // $Add_group = new tbl_team_member_type();
            $Add_to_post_job = new tbl_post_jobs(); 
            // $Add_job_industries =new tbl_job_industries();
            // $Add_group ->type_name      =  $request->group_of_company;
            $Add_to_post_job ->client_name    =  $request->company_name;
            $Add_to_post_job ->privacy_level  =  $request->privacy_level;
            $Add_to_post_job ->sts            =  $request->status;
            $Add_to_post_job ->industry_ID =  $request->industry;
            $Add_to_post_job ->job_code       =  $request->job_code;
            $Add_to_post_job ->job_title      =  $request->job_title;
            $Add_to_post_job ->vacancies      =  $request->no_of_vacancies;
            $Add_to_post_job->employer_ID   =Session::get('id');
            $Add_to_post_job->owner_id=$request->owner_name;
            $Add_to_post_job->company_ID=Session::get('org_ID');
            $date = $request->closeing_date;
            $Add_to_post_job ->last_date   =  date('Y-m-d', strtotime($date));
            $Add_to_post_job ->dated       =  date('Y-m-d', strtotime($date));
            $Add_to_post_job ->job_visa_status=  $request->job_visa_status;
            $Add_to_post_job ->qualification  =  $request->qualification;
            $Add_to_post_job ->country        =  $request->country;
            $Add_to_post_job ->state          =  $request->state;
            $Add_to_post_job ->city           =  $request->city;
            $Add_to_post_job ->job_mode       =  $request->type_of_job;
            $Add_to_post_job ->job_duration   =  $request->job_duration;
            $Add_to_post_job ->job_duration_uom =  $request->day_week;
             $Add_to_post_job ->pay_min        =  $request->pay_min;
            $Add_to_post_job ->	pay_max      =  $request->pay_max;
            $Add_to_post_job ->pay_uom        =  $request->pay_uom;
            $Add_to_post_job ->min_pay_rate        =  $request->pay_min;
            $Add_to_post_job ->	max_pay_rate        =  $request->pay_max;
            $Add_to_post_job ->	pay_rate_umo        =  $request->pay_uom;
             $Add_to_post_job ->experience     =  $request->experience;
            $Add_to_post_job ->min_experience     =  $request->experience;
            $Add_to_post_job ->max_experience     =  $request->experience;
            $Add_to_post_job ->requirement_must=  $request->requirement;
            $Add_to_post_job ->requirement_optional=  $request->requirements;
            $Add_to_post_job ->job_description =  $request->job_desc;
            $Add_to_post_job ->required_skills =  $request->skills;
            $Add_to_post_job->created_by=Session::get('id');
            $Add_to_post_job->last_updated_by=Session::get('id');
            
            // $Add_group->save();     
            $Add_to_post_job->save();
            //Add Notiofication
            // $notification=new Tbl_notification();
        return redirect('employer/posted_jobs');
    }
    
    
    public function editjob($id="")
    {
            ini_set('memory_limit', '-1');
            $toReturn[]=array();
            $toReturn['state']=Tbl_state::get()->toArray();
            $toReturn['city']=Tbl_cities::get()->toArray();
            $toReturn['countries']=Tbl_countries::get()->toArray();
            $toReturn['qualification']=Tbl_qualifications::get()->toArray();
            $toReturn['post_job_edit']=tbl_post_jobs::get()->toArray();
            $toReturn['post_job'] = tbl_post_jobs::where('ID',$id)->first();
            $toReturn['team_member_type']=tbl_team_member_type::get()->toArray();
            $toReturn['team_member']     =tbl_team_member::get()->toArray();
            $toReturn['job_industries']  =tbl_job_industries::get()->toArray();
        return view('edit_posted_job')->with('toReturn',$toReturn);
    }
    
    
    public function updatejob(Request $Request)
    {
        $id=$Request->id;
        $post_job = tbl_post_jobs::where('ID',$id)->update(array(
            'client_name'=>$Request->company_name,
            'privacy_level'=>$Request->privacy_level,
            'sts'=>$Request->status,
            'industry_ID'=>$Request->industry,
            'job_code'=>$Request->job_code,
            'job_title'=>$Request->job_title,
            'country'=>$Request->country,
            'last_date'=>$Request->closeing_date,
            'vacancies'=>$Request->no_of_vacancies,
            'job_visa_status'=>$Request->job_visa_status,
            'qualification'=>$Request->qualification,
            'sts'=>$Request->status,
            'city'=>$Request->city,
            'job_mode'=>$Request->type_of_job,
            'job_duration'=>$Request->job_duration,
            'job_duration_uom'=>$Request->day_week,
            'pay_min'=>$Request->pay_min,
            'pay_max'=>$Request->pay_max,
            'pay_uom'=>$Request->pay_uom,
            'experience'=>$Request->experience,
            'requirement_must'=>$Request->requirement,
            'requirement_optional'=>$Request->requirements,
            'job_description'=>$Request->job_desc,
            'required_skills'=>$Request->required_skills,
            'owner_id'=>$Request->owner_name
        ));
        $Notification=new Tbl_notification();
        $Notification->notification_service_id=$id;
        $Notification->service_type="Update Job";
        $Notification->notification_added_by=Session::get('id');
        $Notification->notification_added_to=$Request->company_name;
        $Notification->applied_id=" ";
        $Notification->notification_text=$Request->job_title."This  job Is Update By ".Session::get('id');
        $mydate=date('Y-m-d');
        $Notification->submit_date=$mydate;
        $Notification->updated_date=$mydate;
        $Notification->read_date=$mydate;
        $Notification->read_status_team_member=1;
        $Notification->read_date_team_member=$mydate;
        // $Notification->notification_service_id=$Add_to_post_job->ID;
        $Notification->save();
    return redirect('employer/posted_jobs');
    }
    
    
    public function view_my_posted_job(){
            $toReturn[]=array();
            $toReturn['post_job'] = tbl_post_jobs::where('employer_ID',Session::get('id'))->paginate(25);
        return view('my_posted_jobs')->with('toReturn',$toReturn);
    }
  
    public function delete_employer($id=''){
            $employer_data=tbl_post_jobs::where('ID',$id)->delete();
        return redirect('employer/posted_jobs');
    }

    public function show_detail($id ="")
    {
        
        $data= tbl_post_jobs::where('ID',$id)->first();
        
        $industry=tbl_job_industries::where('ID',$data->industry_ID)->first();
        // echo"<pre>";
        // print_r($data->industry_ID);
        // exit;
        // return $data;
        return view('team_member_jobdetails')
        ->with('data', $data)
        ->with('industry',$industry);
    }
   
   public function application()
   {
     ini_set('memory_limit', '-1');
    $toReturn['application']= Tbl_seeker_applied_for_job::leftjoin('tbl_post_jobs as post_jobs','tbl_seeker_applied_for_job.job_ID','=','post_jobs.ID')
      ->leftjoin('tbl_job_seekers as seeker','tbl_seeker_applied_for_job.seeker_ID','=','seeker.ID')
      // ->leftjoin('tbl_seeker_applied_for_job as applied_jobs','applied_jobs.job_ID','=','post_jobs.ID ' )
      ->select('post_jobs.job_code as job_code','post_jobs.job_title as job_title','post_jobs.client_name as job_client_name','post_jobs.country as location','post_jobs.job_visa_status as  job_visa','post_jobs.pay_min as pay_min','post_jobs.pay_max as pay_max','seeker.first_name as can_first_name','seeker.last_name as can_last_name','seeker.country as can_location','seeker.visa_status as can_visa','tbl_seeker_applied_for_job.dated as applied_date')
     ->paginate(10);
   	return view('employerApplication')->with('toReturn',$toReturn);
   }

 public function list()
 {
 ini_set('memory_limit', '-1');
        $toReturn = array();
        $source="Internal";
        $personal = \DB::table('tbl_job_seekers')
                                ->select('tbl_job_seekers.ID as id','tbl_job_seekers.first_name as first','tbl_job_seekers.last_name as last',
                                'tbl_job_seekers.dob as dob','tbl_job_seekers.city as city','tbl_job_seekers.state as state','tbl_job_seekers.visa_status as visa',
                                'tbl_job_seekers.email as email','tbl_job_seekers.mobile as mobile','tbl_job_seekers.skype_id as skype_id',
                                'tbl_seeker_applied_for_job.total_experience as experience','tbl_seeker_academic.degree_title as degree')
                               ->leftjoin('tbl_seeker_experience','tbl_seeker_experience.seeker_ID', '=' , 'tbl_job_seekers.ID')
                               ->leftjoin('tbl_seeker_academic','tbl_seeker_academic.seeker_ID', '=' ,'tbl_job_seekers.ID' )
                               ->leftjoin('tbl_seeker_applied_for_job','tbl_seeker_applied_for_job.seeker_ID', '=' ,'tbl_job_seekers.ID')
                               
                               // ->where('tbl_job_seekers.ID','=','*')
                                ->orderBy('tbl_job_seekers.ID','asc')
                               ->paginate(10);
                            
        return view('search_resume')->with('personal',$personal)->with('source',$source);
 
      
    }
    public function list_delete($id ="")
    {
        
        $personal= tbl_job_seekers::where('ID',$id)->delete();
     
        return redirect('employer/search_resume');
    }
    
    
    public function show_form(){
        $toReturn=array();
        $toReturn['countries']=Tbl_countries::get()->toArray();
        $toReturn['cities']=Tbl_cities::get()->toArray(); 
        $toReturn['degree']=Tbl_seeker_academic::get()->toArray();
        $toReturn['visa_type']=Tbl_visa_type::get()->toArray();

       return view('post_new_candidate')->with('toReturn',$toReturn);
    }
    
    public function post_new_candidate(Request $request)
    {
        
    $validation = Validator::make($request->all(), [
            'cv_file' => 'required'
        ]);
  
      $cv = $request->file('cv_file');
      $store_cv = rand() . '.' . $cv->getClientOriginalExtension();
      $cv->move(public_path('seekerresume'), $store_cv);
      if ($request->hasFile('file_other1')){
      $file_other1 = $request->file('file_other1');
      $file_other1_cv = rand() . '.' . $file_other1->getClientOriginalExtension();
      $file_other1->move(public_path('seekerresume'), $file_other1_cv);
      }
      if ($request->hasFile('file_other2')){
      $file_other2 = $request->file('file_other2');
      $file_other2_cv = rand() . '.' . $file_other2->getClientOriginalExtension();
      $file_other2->move(public_path('seekerresume'), $file_other2_cv);
      }
      
        $postcandidate = new Tbl_job_seekers(); 
        $postcandidate->first_name=$request->first_name;
        $postcandidate->middle_name=$request->middle_name;
        $postcandidate->last_name=$request->last_name;
        $birthday = $request->dob_year . '-' . $request->dob_month . '-' . $request->dob_day;
        $postcandidate->dob=$birthday;
        $postcandidate->gender=$request->gender;
        $postcandidate->email=$request->email;
        $postcandidate->skype_id=$request->skype_id;
        $postcandidate->ssn=$request->ssn;
        $postcandidate->visa_status=$request->visa_status;
        $postcandidate->country=$request->country;
        $postcandidate->state=$request->state;
        $postcandidate->city=$request->city;
        $postcandidate->address_line_1=$request->addressline1;
        $postcandidate->address_line_2=$request->addressline2;
        $postcandidate->mobile=$request->mobilephone;
        $postcandidate->home_phone=$request->homephone;
        $postcandidate->cv_file=$store_cv;
        
        if ($request->hasFile('file_other1')){
        $postcandidate->otherdocuments1=$file_other1_cv;
        }
        if ($request->hasFile('file_other2')){
        $postcandidate->otherdocuments2=$file_other2_cv;
        }
        $postcandidate->fed_id=12;
           $mydate=date('Y-m-d');
        $postcandidate->dated=$mydate;
        $postcandidate->experience="";
        $postcandidate->default_cv_id=1;
        // $postcandidate->cv_file=;
        $postcandidate->skills="";
        $postcandidate->employer_id=Session::get('id');
        $postcandidate->created_by=Session::get('id');
        $postcandidate->is_employer=Session::get('id');
        $postcandidate->owner_id="";
        $postcandidate->min_pay_rate="";
        $postcandidate->max_pay_rate="";
        $postcandidate->pay_rate_umo="";
        $postcandidate->save();
        $id=$postcandidate->ID;

    
        // educational insert
        $degree = $request->degree;   
           foreach($degree as $key => $value) {
            $seeker_academic = new Tbl_seeker_academic();
            $seeker_academic->seeker_ID	=$id;
            $seeker_academic->degree_title    = $degree[$key];
            $seeker_academic->major           = $request->major_subject[$key];
            $seeker_academic->institude       = $request->institute[$key];
            $seeker_academic->city            = $request->edu_city[$key];
            $seeker_academic->country         = $request->edu_country[$key];
            $seeker_academic->completion_year =$request->completion_year[$key];               
            $seeker_academic->save();

        }

        //experiance  start
        $job_title_experience = $request->job_title;              
        foreach($job_title_experience as $key => $value ){
            $seeker_exprience = new Tbl_seeker_experience();
            $seeker_exprience->seeker_ID=$id;
            $seeker_exprience->  job_title  = $job_title_experience[$key]; 
            $seeker_exprience->company_name = $request->company_name[$key];
            $seeker_exprience->city         = $request->exp_city[$key];
            $seeker_exprience->country      = $request->exp_country[$key];
            $seeker_exprience->start_date   = $request->start_date[$key];
            $seeker_exprience->end_date     = $request->end_date[$key];
            $seeker_exprience->save();  
        }
        //   experiance end


        //skill  start
        $seeker_skill_name = new Tbl_seeker_skills();
        $seeker_skill_name->skill_name = $request->skill;
        return redirect('employer/search_resume');
    }
    
    // function uploaded_resume(Request $request)
    //   {
    //     return $request;
    //  $validation = Validator::make($request->all(), [
    //   'Upload_image' => 'required'
    //  ]);
    //  if($validation->passes())
    //  {
    //   $image = $request->file('select_file');
    //   $new_name = rand() . '.' . $image->getClientOriginalExtension();
    //   $image->move(public_path('images'), $new_name);
    //   return response()->json([
    //   'message'   => 'Image Upload Successfully',
    //   'uploaded_image' => '<img src="/images/'.$new_name.'" class="img-thumbnail" width="300" />',
    //   'class_name'  => 'alert-success'
    //   ]);
    //  }
    //  else
    //  {
    //   return response()->json([
    //   'message'   => $validation->errors()->all(),
    //   'uploaded_image' => '',
    //   'class_name'  => 'alert-danger'
    //   ]);
    //  }
    // }
    
    

    
    // Team member managing functions
    public function showteam()
    { 
         $module=Tbl_module::all();
        return view('create_team_member')
        ->with('group', Tbl_team_member_type::all())
        ->with('country', tbl_countries::all())
        ->with('city', tbl_cities::all())
        ->with('module',$module);
    }
    public function showteamadd(Request $Request)
    { 
    	$team=new tbl_team_member();
    	$team->employer_id=Session::get('id');
    	$team->company_id=Session::get('org_ID');
        $team->team_member_type=$Request->group;
        $team->assigned_jobs=" ";
        $team->email=$Request->email;
        $team->pass_code=$Request->password;
        $team->full_name=$Request->full_name;
        $team->first_name=$Request->full_name;
        $team->profile_image=$Request->profile_image;
        $team->jobs_history=$Request->jobs_history;
        $team->is_active="active";
        $date=date('Y-m-d');
        $team->dated=$date;
        $team->phone=$Request->phone;
        $team->mobile_number=$Request->mobile_number;
        $team->sts='active';
       // $team->country=$Request->country;
        // $team->state=$Request->state;
        // $team->city=$Request->city;
        // $team->loc_time_zone=$Request->timea;
        // $team->dis_time_zone=$Request->timeb;
        $time=date('Y-m-d h:i:s',time());
        $team->first_login_date=$time;
        $team->last_login_date=$time;
        $team->last_updated_date=$time;
        $team->last_updated_by=Session::get('id');
        $team->save();
        $module=$Request->module;     
        foreach ($module as $key => $value) {
        $permission= new Tbl_team_member_permission();
        $permission->team_member_id=$team->id;
        $permission->employer_id=Session::get('id');
        $permission->company_id=Session::get('org_ID');
        $permission->permission_value=$value;
        $permission->is_read = (!empty($Request->input('read'.$value))) ? "yes":"no";
        $permission->is_add = (!empty($Request->input('add'.$value))) ? "yes":"no";
        $permission->is_edit = (!empty($Request->input('edit'.$value))) ? "yes":"no";
        $permission->is_delete = (!empty($Request->input('delete'.$value))) ? "yes":"no";   
        $permission->save();
        }
        $user_tbl=new user();
        $user_tbl->full_name=$Request->full_name;
        $user_tbl->email=$Request->email;
        $user_tbl->password=$Request->password;
        $user_tbl->user_type="teammember";
        $user_tbl->org_ID=Session::get('org_ID');
        $user_tbl->save();
        return redirect('employer/manageteammember');

    }
    
    
    public function addteam()
    { 
    	return view('create_team_member_group');
    }
    
    
    public function addteaminsert( Request $Request)
    { 
        $teamType=new Tbl_team_member_type();
        $teamType->type_name=$Request->groupname;
        $teamType->status=1;
        $date=date('Y-m-d h:i:s');
        $teamType->date_created=$date;
        $teamType->date_closed=$date;
        $teamType->last_updated_date=$date;
        $teamType->last_updated_by=Session::get('id');
        $teamType->save();
        return redirect('employer/manageteammember');
    }
    
    public function editteam(Request $Request)
    {
        $id=$Request->id;
        $editteamgroup = Tbl_team_member_type::where('type_ID',$id)->update(array(
                'type_name'=>$Request->type_namegroup
            ));
        return redirect('employer/manageteammember');
    }
    

    public function manageteam()
    { 
        $team_member= tbl_team_member::leftjoin('tbl_team_member_type as member_type','tbl_team_member.team_member_type','=','member_type.type_ID')
        ->select('tbl_team_member.ID as ID','tbl_team_member.first_name as first_name','member_type.type_name as team_member_type','tbl_team_member.city as city','tbl_team_member.state as state','tbl_team_member.country as  country','tbl_team_member.loc_time_zone as loc_time_zone','tbl_team_member.first_login_date as first_login_date','tbl_team_member.last_login_date as last_login_date','tbl_team_member.last_updated_date as last_updated_date','tbl_team_member.is_active as is_active','tbl_team_member.ID as ID')
        ->get();
         $team_member_type=tbl_team_member_type::all();
        return view('manage_team_members')->with("team_member",$team_member)->with("team_member_type",$team_member_type);
    }
    public function delete_teammember($id ="")
    {
            $team_member_del= tbl_team_member::where('ID',$id)->delete();
        return redirect('employer/manageteammember');
    }
    public function edit_teammember($id ="")
    {
        $data= tbl_team_member::where('ID',$id)->first();
        
        return view('edit_team_member')
        ->with('data', $data)
        ->with('group', Tbl_team_member_type::all())
        ->with('country', tbl_countries::all())
        ->with('city', tbl_cities::all());
    }
    public function edit_teammember_add(Request $Request)
    {
        $date=date('Y-m-d h:i:s',time());
        
        tbl_team_member::where('ID', $Request->ID)->update(array(
        'team_member_type'=>$Request->group,
        'email'=>$Request->email,
        'pass_code'=>$Request->password,
        'full_name'=>$Request->full_name,
        'first_name'=>$Request->full_name,
        'profile_image'=>$Request->profile_image,
        'jobs_history'=>$Request->jobs_history,
        'phone'=>$Request->phone,
        'mobile_number'=>$Request->mobile_number,
        'country'=>$Request->country,
        'state'=>$Request->state,
        'city'=>$Request->city,
        'loc_time_zone'=>$Request->timea,
        'dis_time_zone'=>$Request->timeb,
        'last_updated_date'=>$date,
        'last_updated_by'=>2
        ));
       return redirect('employer/manageteammember');
    }
    public function manageteamadd()
    { 
        $team_member_type=tbl_team_member_type::all();
    	return view('manage_team_members_group')->with("team_member_type",$team_member_type);
    // 	return view('manage_team_members')->with("team_member_type",$team_member_type);
    
    }
    public function delete_teammember_type($id ="")
    {
        $team_member_del= tbl_team_member_type::where('type_ID',$id)->delete();
        
        return redirect('employer/manageteammember');
    }
    public function manageteamaddedit( Request $Request)
    {
        $type_ID=$Request->type_id;
        $team_type= tbl_team_member_type::where('type_ID',$type_ID)->first();
        $type_name=$Request->type_name;
        
        tbl_team_member_type::where('type_ID', $type_ID)->update(array('type_name'=>$type_name));
        return redirect('employer/manageteammember');

        
    }
  
    public function index(){

        return view ('post_new_contacts');
    }
    public function add(Request $request){
        
        $contact_object = new Tbl_post_contacts;
        $contact_object ->sub_name      = $request ->salutation;
        $contact_object ->cont_per_name = $request ->name;
        $contact_object ->phone_c       = $request ->phone_c;
        $contact_object ->phone_w       = $request ->phone_w;
        $contact_object ->email_h       = $request ->email_h;
        $contact_object ->email_w       = $request ->email_w;
        $contact_object ->country       = $request ->country;
        $contact_object ->state         = $request->state;
        $contact_object ->city          = $request->city;
        $contact_object ->company_name  = $request->company_name;
        $contact_object ->designation   = $request->designation;
        $contact_object->status="active";
        $mydate=date('Y-m-d');
        $contact_object->created_date=$mydate;
        $contact_object->created_by="rohit";
        $contact_object->last_updated_by="";
        $contact_object->last_updated_date=$mydate;
        $contact_object->employer_id=12;
        $contact_object -> save();
    return redirect('employer/my_posted_contacts');
        
    }
    
    
    public function show()
    {
            $contact_object =Tbl_post_contacts::all();   
            $emailList = Tbl_email_list_contacts::all();
            $email=Tbl_email_list::all();
        return view('my_posted_contacts')->with('list',$emailList)->with('contacts',$contact_object)->with('email',$email);
    } 
    
    public function delete($id="")
    {
            $contact_delete = Tbl_post_contacts::where('id',$id)->delete();
        return redirect('employer/my_posted_contacts');
    }


    public function add_email_form(Request $request)
    {
            $emailList = new Tbl_email_list_contacts;
            $emailList ->salutation = $request->salutation;
            $emailList ->first_name = $request->firstname;
            $emailList ->last_name  = $request->lastname;
            $emailList ->full_name  = $request->fullname;
            $emailList ->email_contact_id =$request->emailid;
            $emailList ->add_in_contact_db = $request->contactdatabase;
            $emailList ->save();
        return redirect('employer/my_posted_contacts');
    }

    public function show_email_form()
    {
        return view('post_new_email_contact');
    }

    public function delete_email($id="")
    {     
            $email_delete  = Tbl_email_list_contacts::where('id',$id)->delete();
        return redirect('employer/my_posted_contacts');
    }
    
    public function delete_email_list($id="")
    {  
           $email_delete_list=Tbl_email_list::where('id',$id)->delete();
        return redirect('employer/my_posted_contacts');
    }

}
