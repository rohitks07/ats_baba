<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_visa_type extends Model
{
    protected $table='tbl_visa_type';
    public $timestamps= false;
}
