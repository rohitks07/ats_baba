<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_team_member extends Model
{
    //
    public $timestamps = false;
     public  $table = "tbl_team_member";
}
