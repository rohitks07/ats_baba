<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_candidate_mail extends Model
{
    public $timestamps=false;
    protected $table='tbl_candidate_mail';
}
