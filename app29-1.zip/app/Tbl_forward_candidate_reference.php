<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_forward_candidate_reference extends Model
{
    public $timestamps = false;
    public  $table = "tbl_forward_candidate_reference";
}
