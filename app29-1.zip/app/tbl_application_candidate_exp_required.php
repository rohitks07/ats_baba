<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_application_candidate_exp_required extends Model
{
    public $timestamps = false;
    public  $table = "tbl_application_candidate_exp_required";
}
