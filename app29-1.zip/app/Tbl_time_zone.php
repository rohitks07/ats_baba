<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_time_zone extends Model
{
    public $timestamp=false;
    protected $table="tbl_time_zone";
}
