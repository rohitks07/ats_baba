<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_interview_mail extends Model
{
    public $timestamps= false;
    protected $table="tbl_interview_mail";
}
 