<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_last_email extends Model
{
    
    public $timestamps = false;
    public  $table = "tbl_last_email";
}
