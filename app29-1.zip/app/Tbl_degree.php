<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_degree extends Model
{
	public $timestamps = false;
 	public  $table = "tbl_degree";
}
