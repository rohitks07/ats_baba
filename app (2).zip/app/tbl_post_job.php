<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_post_job extends Model
{
    public $timestamps = false;
    public  $table = "tbl_post_jobs";
}
