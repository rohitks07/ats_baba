<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_email_list_contacts extends Model
{
    public $timestamps= false;
    protected $table='tbl_email_list_contacts';
    
  
}
