<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_job_industries extends Model
{
    public $timestamps = false;
    protected  $table = "tbl_job_industries"; 
}
