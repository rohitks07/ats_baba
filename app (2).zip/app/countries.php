<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class countries extends Model
{
    public $timestamps = false;
     public  $table = "countries";

}
