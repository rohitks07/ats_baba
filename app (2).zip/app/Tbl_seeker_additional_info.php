<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_seeker_additional_info extends Model
{
    public $timestamps = false;    
    public  $table = "tbl_seeker_additional_info";
}
