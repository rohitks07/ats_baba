<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class invite_employer extends Model
{
    public $timestamps = false;
    public  $table = "tbl_invite_employer";
}
