<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_status extends Model
{
    //
}
