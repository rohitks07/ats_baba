<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tbl_schedule_preview extends Model
{
    public $timestamps=false;
    protected $table='tbl_schedule_preview';
}
