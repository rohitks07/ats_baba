<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_teammember_send_report extends Model
{
    public $timestamps = false;
    public  $table = "tbl_teammember_send_report";
}