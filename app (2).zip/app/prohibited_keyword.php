<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class prohibited_keyword extends Model
{
    public $timestamps = false;
     public  $table = "tbl_prohibited_keywords";

}
